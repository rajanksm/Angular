import {Contact} from './contact';

export const CONTACTS:Contact[]=[
  {name:'Sriram',email:'murthy@yahoo.com',phone:'2393993'},
  {name:'Raju',email:'Raju@gmail.com',phone:'4543993'},
  {name:'Lalitha',email:'lalitha@yahoo.com',phone:'543454'},
  {name:'Kavitha',email:'kavitha@yahoo.com',phone:'454493'}
]