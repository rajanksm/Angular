import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { SPArouting } from './app.routing';
import { LoginComponent } from './components/Login.component';
import { ServiceComponent } from './components/service.component';
import { ContactListComponent } from './components/contactlist.component';
import { ShowComponent } from './components/show.component';
import { NewContactComponent } from './components/newcontact.component';
import { PageNotFoundComponent } from './components/pagenotfound.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ContactListComponent,
    ShowComponent,
    ServiceComponent,    
    NewContactComponent,
    PageNotFoundComponent
    ],
  imports: [
    BrowserModule,FormsModule,
    SPArouting
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
