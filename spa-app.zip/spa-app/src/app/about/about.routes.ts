import { Route, RouterModule } from '@angular/router';
import { AboutComponent } from './about.component';

export const AboutRoutes: Route[] = [
  { path: '', component: AboutComponent,pathMatch: 'full'}
];

export default RouterModule.forChild(AboutRoutes);
