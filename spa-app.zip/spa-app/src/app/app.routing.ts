import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './components/Login.component'
import { AlwaysAuthGuard } from './services/AlwaysAuthGuard';
import { ContactListComponent } 
                from './components/contactlist.component';
import { ShowComponent } from './components/show.component';
import { NewContactComponent } from './components/newcontact.component';
import { ServiceComponent } from './components/service.component';
import {PageNotFoundComponent} from './components/pagenotfound.component'
export const customRoutes: Routes = [    
    {path:'',component:LoginComponent,canActivate:[AlwaysAuthGuard]},
    {path:'contacts',component:ContactListComponent},
    {path:'show/:selected',component:ShowComponent},
    {path:'newcontact',component:NewContactComponent},
    {path:'services',component:ServiceComponent},
    {path:'dynamic',
        loadChildren: () => import('./about/about.module').then(mod => mod.AboutModule)},
    {path: '**', component: PageNotFoundComponent} //catch all = **    
];
export const SPArouting = RouterModule.forRoot(customRoutes);