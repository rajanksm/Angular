import { Component } from '@angular/core';


@Component({
  template:`
     <h2 class="bg-danger text-center text-warning">
     Sorry...... Page not found (404 - Error)
     </h2>
     <h3> <a [routerLink]="['/']">Back</a></h3>
  
  `
})
export class PageNotFoundComponent{

}