export interface Prototype{
    
    clone(): Prototype;
}