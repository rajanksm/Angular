import { Component } from '@angular/core';
import { Movie } from './movie';
@Component({
  selector: 'app-memento',
  template: '<h1>Memento pattern</h1>',
 })
export class AppComponent {

  private memento: Movie;
  constructor(){
    this.memento = new Movie("Title", 2015);
    let movieTmp = this.memento.clone();
    this.memento.setTitle("Another Title");
    //Prints Another title
    console.log(this.memento.getTitle());
    this.memento.restore(movieTmp);
    //Prints Title
    console.log(this.memento.getTitle());
  }
}
