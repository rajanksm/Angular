import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { SingletonComponent } from './singleton/singleton.component';
import { OtherComponent } from './singleton/other/other.component';

@NgModule({
  declarations: [
    AppComponent,
    SingletonComponent,OtherComponent

  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
