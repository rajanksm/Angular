import { Component } from '@angular/core';
import { UserFactory } from './factory';
import { User } from './user';

@Component({
  selector: 'app-factory',
  template: '<h1>Factory pattern Demo</h1>',
 
})
export class FactoryComponent {  
  constructor(){    
    let userFromJSONAPI: User = JSON.parse(
      '[{"lastName":"Murthy","firstName":"Srirama"}]')[0];
    console.log(userFromJSONAPI);

    let user = UserFactory.buildUser(
      JSON.parse('[{"lastName":"Kiran","firstName":"Kumar"}]')[0]);
    console.log(user);
    user.hello();
  }
}
