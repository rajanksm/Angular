import { User } from './user'

export class UserFactory{
// Builder with Factory
    static buildUser(jsonUser: any): User {
        return new User(
            jsonUser.firstName,
            jsonUser.lastName
        );
    }
}
