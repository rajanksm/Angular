
import {Component} from "@angular/core";

@Component({
    selector: 'my-app',
    template: `
    <h1>Injector Demo <link-to-code></link-to-code></h1>
    <users></users>
`
})
export class AppComponent{

}