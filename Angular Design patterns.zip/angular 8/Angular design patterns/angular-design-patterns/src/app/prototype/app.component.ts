import { Component } from '@angular/core';

@Component({
  selector: 'app-prototype',
  template: '<h1>Prototype Pattern</h1>',
 
})
export class AppComponent {
  
  constructor(){
    for (var index = 0; index < 11; index++) {    
      console.log(MoviePool.getMovie());
    }
  }
}
