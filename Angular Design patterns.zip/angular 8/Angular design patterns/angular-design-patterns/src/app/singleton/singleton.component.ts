import { Component } from '@angular/core';
import { APIService } from './api.service';

@Component({
  selector: 'app-singleton',
  template: '<app-other><app-other>'
})
export class SingletonComponent {
  constructor(private api: APIService) {
    console.log(api);
  }
}
