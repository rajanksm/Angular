// 1. The simplest singleton in JavaScript is an object literal;
//  it provides a quick and cheap way to create a unique object:
const singletonA = {
        foo(): void {
            console.log('bar');
        }
    };
    
// 2. anynymous constructor of ES6
    const singletonB = (() => {
        let bar = 'bar';

        return {
            foo(): void {
                console.log(bar);
            }
        };
    })();
    
//3.  private varaible
    const singletonC = new class {
        bar = 'bar';
        
        foo(): void {
            console.log(this.bar);
        }
    };
    
// 4. Singleton pattern
//lazy initialization: the object only gets
//initialized when it gets accessed the first time.

    class Singleton {
        private static _default: Singleton;

        static get default(): Singleton {
            if (Singleton._default) {
                return Singleton._default;
            } else {
                let singleton = new Singleton();
                Singleton._default = singleton;
                return singleton;
            }
        }
    }

    let x1 = Singleton.default
    let x2 = Singleton.default
    //let x=new Singleton()
    alert(x1==x2)

