import { Component } from '@angular/core'

@Component({
    selector:'app-start',
    templateUrl:'./start.component.html'
})
export class StartComponent{
    // constructor
    // properties
    // methods (event handles)
    msg:string
    constructor(){
        this.msg="Welcome to NG"
    }
}