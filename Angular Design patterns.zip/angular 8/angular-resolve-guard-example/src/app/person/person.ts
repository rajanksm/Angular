export interface Person { 
	personId: string;
	name: string;
	city: string;
}