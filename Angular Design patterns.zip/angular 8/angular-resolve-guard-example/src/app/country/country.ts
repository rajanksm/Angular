export interface Country { 
	countryId: string;
	name: string;
	capital: string;
	currency: string;
}
    