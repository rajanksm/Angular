export interface UserInfo{
    userName:string,
    password:string
    
}

//let u:UserInfo={userName:'murthy',password:'welcome'}