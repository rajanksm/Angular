import { Injectable } from '@angular/core';

import {UserInfo} from './UserInfo';

@Injectable()
export class LoginService {
  
  CheckUser(user:UserInfo):boolean{
      if(user.userName=='murthy' && user.password=='hi'){
        return true;
      } else {
        return false;
        } 
  
  }
}
