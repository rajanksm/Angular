import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeLoanComponent } from './homeloan.component';
import { HomeLoanService } from './homeloan.service';

@NgModule({
    imports: [CommonModule],
    declarations: [HomeLoanComponent],
    providers: [HomeLoanService],
    exports: [HomeLoanComponent]
})
export class HomeLoanModule { }
