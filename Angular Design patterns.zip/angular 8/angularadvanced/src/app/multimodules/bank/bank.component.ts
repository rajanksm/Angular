import {Component} from '@angular/core';

@Component({
    selector:'app-bank',
    template:`
     <h1 class="well text-danger">
        <app-savings></app-savings>
     </h1>

     <h1 class="well text-success">    
          <app-homeloan></app-homeloan>   
      </h1>
    `
})
export class BankComponent{    
}