import {Component,OnInit} from '@angular/core';
import {SavingsService} from './savings.service';
@Component({
    selector:'app-savings',
    template:`
     <h1 class="well text-danger">Hi! {{serviceName}}</h1>
    `
})
export class SavingsComponent implements OnInit{
    serviceName:string  | null;
    service:SavingsService | null;

    constructor(ss:SavingsService){
        this.service=ss;
    }    
    ngOnInit() {
      this.serviceName=  this.service.getService();
    }
}