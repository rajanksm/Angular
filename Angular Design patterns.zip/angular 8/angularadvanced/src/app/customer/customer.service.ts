import { Injectable } from '@angular/core'
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'

interface Customer{
  name: string
}

@Injectable()
class CustomerService {
  constructor(private http: HttpClient) {}

  getAllCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>('http://localhost:8000/api/Customers')
  }

  getCustomer(name: string): Observable<Customer> {
    return this.http.get<Customer>('http://localhost:8000/api/Customers/' + name)
  }

  insertCustomer(Customer: Customer): Observable<Customer> {
    return this.http.post<Customer>('http://localhost:8000/api/Customers/', Customer)
  }

  updateCustomer(Customer: Customer): Observable<void> {
    return this.http.put<void>(
      'http://localhost:8000/api/Customers/' + Customer.name,
      Customer
    )
  }

  deleteCustomer(name: string) {
    return this.http.delete('http://localhost:8000/api/Customers/' + name)
  }
}