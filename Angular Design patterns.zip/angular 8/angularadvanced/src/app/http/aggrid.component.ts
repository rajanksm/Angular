
//ng new ag-app --style scss --routing false
//npm install --save ag-grid-community ag-grid-angular
// import in app.module
//in styles.css  add ag-grid styles.

import {Component} from '@angular/core'
import {HttpClient} from '@angular/common/http'


@Component({
    selector: 'app-ag-grid',
    templateUrl: './ag-grid.component.html',
})
export class AgGridComponent {
    title = 'Ag-grid Demo by Murthy';
    rowData:any
        
    constructor(private http: HttpClient) {
    }
  
    columnDefs = [
        {headerName: 'make', field: 'make', sortable: true, filter: true, checkboxSelection: true },
        {headerName: 'model', field: 'model', sortable: true, filter: true },
        {headerName: 'price', field: 'price', sortable: true, filter: true }
    ];

  
    ngOnInit() {
        this.rowData = this.http.get('https://api.myjson.com/bins/15psn9');
    }    
}
