import { Component } from '@angular/core';
import {FormControl} from '@angular/forms';

import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import {map} from 'rxjs/operators'

@Component({
    selector: "app-bank",
    template: `
    <div class="container">
      <h3 style="background:orange">Web API with Angular 6 by  Murthy</h3>  
     
    `
})
export class BankComponent {
    //http://localhost:27047/api/bank
    
    private url: string ='http://localhost:27047/api/bank';

    constructor(private http: HttpClient) {
        this.getCustomers()
            .subscribe((res: any) => {
                alert(res)
            },
            (err: any) =>
                console.log(
                `Can't get details  Error code: %s, URL: %s`, err.message, err.url  ),
            () => console.log('done')
            );
    }    
    //Ajax call here (write this code in service)
    getCustomers() {
        return this.http.get(this.url)
            .pipe(map((response:any) => {
                console.log(response);
                return response
            }));
    }
}
// end