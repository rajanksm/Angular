//https://www.learnrxjs.io/operators

import {Component} from '@angular/core';
import {filter,map,mapTo } from 'rxjs/operators';
import {from} from 'rxjs'
import { Observable } from 'rxjs';

import { interval, merge } from 'rxjs';

import { throwError, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

import {forkJoin} from 'rxjs';
import {MyService} from './MyService'

@Component({
  selector: 'app-rx',  
  providers:[MyService],
  template: `
       <h1 style="background:yellow;text-align:center">RX JS Demo</h1>
       <button (click)="createDemo()">create</button>       
   <button (click)="mapDemo()">map</button>
   <button (click)="mergeDemo()">merge</button>
   <button (click)="FilterDemo()">filter</button>
   <button (click)="errorDemo()">catch/exception</button>
   <button (click)="toPromiseDemo()">toPromise</button>
   <button (click)="forkJoinDemo()">forkJoin</button>
   <div>
   <h2>forkJoin Example</h2>
   <ul>
     <li> {{propOne}} </li>
     <li> {{propTwo}} </li>
     <li> {{propThree}} </li>
   </ul>
 </div>
  `,
})
export class RxAppComponent {

    public propOne: string;
    public propTwo: string;
    public propThree: string;
    constructor(private _myService: MyService) {}
  
    /*   
//emits any number of provided values in sequence
const source = of(1, 2, 3, 4, 5);
//output: 1,2,3,4,5
const subscribe = source.subscribe(val => console.log(val));
    */

  createDemo(){
//  Create an observable that emits 'Hello' and 'RXJS' on   subscription.

const hello = Observable.create(function(observer) {
  observer.next('Hello');
  observer.next('RXJS');
});
//output: Hello,RXJS
const subscribe = hello.subscribe(val => console.log(val));
  }

  /* interval
  const source = interval(1000);
  const subscribe = source.subscribe(val => console.log(val));//0,1,2,3,4,5..
  */

  mapDemo(){
      //Apply projection with each value from source.

//emit (1,2,3,4,5)
const source = from([1, 2, 3, 4, 5]);
//add 10 to each value
const example = source.pipe(map(val => val + 10));
//const example = source.pipe(take(1));
//const example = source.pipe(takeWhile(val => val <= 4));
//output: 11,12,13,14,15
const subscribe = example.subscribe(val => console.log(val));
  }

  mergeDemo(){
    //Turn multiple observables into a single observable.
//emit every 2.5 seconds
const first = interval(2500);
//emit every 2 seconds
const second = interval(2000);
//emit every 1.5 seconds
const third = interval(1500);
//emit every 1 second
const fourth = interval(1000);

//emit outputs from one observable
const example = merge(
  first.pipe(mapTo('FIRST!')),
  second.pipe(mapTo('SECOND!')),
  third.pipe(mapTo('THIRD')),
  fourth.pipe(mapTo('FOURTH'))
);
//output: "FOURTH", "THIRD", "SECOND!", "FOURTH", "FIRST!", "THIRD", "FOURTH"
const subscribe = example.subscribe(val => console.log(val));
  }

   
  FilterDemo(){
    //emit (1,2,3,4,5)
const source = from([1, 2, 3, 4, 5]);
//filter out non-even numbers
const data= source.pipe(filter(num => num % 2 === 0));
//output: "Even number: 2", "Even number: 4"
const result = data.subscribe(val => console.log(`Even number: ${val}`));
 }

 errorDemo(){

    //emit error
    const source = throwError('This is an error!');
    //gracefully handle error, returning observable with error message
    const example = source.pipe(catchError(val => of(`I caught: ${val}`)));
    //output: 'I caught: This is an error'
    const subscribe = example.subscribe(val => console.log(val));
 }

 forkJoinDemo(){
 // simulate 3 requests with different delays
 forkJoin(
    this._myService.makeRequest('Request One', 2000),
    this._myService.makeRequest('Request Two', 1000),
    this._myService.makeRequest('Request Three', 3000)
  )
  .subscribe(([res1, res2, res3]) => {
    this.propOne = res1;
    this.propTwo = res2;
    this.propThree = res3;
  });
 }


 /*
 toPromiseDemo(){
    const sample = val => Rx.Observable.of(val).delay(5000);
    //convert basic observable to promise
    const example = sample('First Example')
      .toPromise()
      //output: 'First Example'
      .then(result => {
        console.log('From Promise:', result);
      });
 }
 */

}