/*
@Component({
    selector:'app-test',
    template:`
    <div>
        <input type="text" [(ngModel)]="temp">
         {{temp | temperature:'FtoC'  | number:"1.1"}}

        
    </div>
    `
})
class Demo{
    temp=40;
}

*/

import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'temperature'})
export class TemperaturePipe implements PipeTransform {
 
    transform(value:number, fromTo: string): any {
        //value=40
   // http.get("url")
   if ( !fromTo) {
     throw "Temperature pipe requires parameter FtoC or CtoF ";
    }
     return (fromTo == 'FtoC') ?
        		(value - 32) * 5.0/9.0:  // F to C
                   value * 9.0 / 5.0 + 32;  // C to F
    }
}

