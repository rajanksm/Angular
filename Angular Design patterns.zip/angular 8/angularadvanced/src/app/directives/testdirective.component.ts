import { Component } from '@angular/core';

@Component({
    selector: 'app-testdir',
    template: `
    <h2 style='background-color:orange'>
              Angular Directives
    </h2>  
   <h3 [myHidden]="show" style='background:lightblue'>  
     <div class='hover-focus'>
        Welcome to Hidden Custom Attribute Directive
     </div>
  </h3>  	
  <h1 class="hover-focus">Thanks for attending Angular 7</h1>
    `
})  
export class TestDirectiveComponent {
  show:boolean=false;  // change to false and observer    
 }

 