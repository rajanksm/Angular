/*
Component - Component directive - creating custom html tag

<div [myHidden]="flag" id="div1">
    <span>Welcome to Angular 6</span>
    <app-barchart></app-barchart>
</div>

<span [myHidden]=show>
<h2>Hi</h2>
</span>
export class test{
    flag:boolean=true
    products:Products[]
}

<p [myHidden]="false"></p>

Steps:
1. Import ElementRef, Renderer, Directive, Input
2. Decorate class with Directive and name it 
3. Inject ElementRef and Renderer in constructor to manipulate Shadow DOM
4. ngOnInit or ngOnChanges ... to implement logic
5. Consume the directive

*/


// ./app/shared/hidden.directive.ts
//load DOM specific helpers
import { Directive, ElementRef, Input, Renderer }    from '@angular/core';
@Directive({ selector: '[myHidden]' })
export class HiddenDirective  {
    constructor(public el: ElementRef, public renderer: Renderer) {}
                     
    @Input() 
    myHidden: boolean;    

    ngOnInit(){
      console.log(this.myHidden);//true

        if(this.myHidden) {
           console.log(this.el.nativeElement)    

           this.renderer.setElementStyle(
                     this.el.nativeElement,  'display', 'none' );          
        }
    }
}



