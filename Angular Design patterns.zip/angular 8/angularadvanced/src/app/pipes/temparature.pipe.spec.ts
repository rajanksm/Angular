import {TemperaturePipe} from './temparature.pipe'

describe('Temperature Pipe', () => {
  it('create an instance', () => {
    const pipe = new TemperaturePipe();
    expect(pipe).toBeTruthy();
    expect(pipe.transform(100,'FtoC')).toEqual(37.78)
    expect(pipe.transform(100,'CtoF')).toEqual(212)
  });
});
