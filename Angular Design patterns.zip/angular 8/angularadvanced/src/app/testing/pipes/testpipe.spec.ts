
import { TestPipe } from './testpipe.pipe';

describe('Testpipe ', () => {
  it('create an instance of pipe', () => {
    const pipe = new TestPipe();
    expect(pipe).toBeTruthy();

    let result= pipe.transform(10)
    expect(result).toEqual(100)
  });
});
