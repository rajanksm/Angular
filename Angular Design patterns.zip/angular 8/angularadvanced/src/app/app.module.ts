import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms'

import { AgGridModule } from 'ag-grid-angular';

// import {HttpModule} from '@angular/http  in angular 5.0 
import {HttpClientModule} from '@angular/common/http'

import {JsonpModule} from '@angular/http'

import { WeatherComponent } from './http/weather.component'; //REST
import {HttpComponent} from './http/http.component'    //Node js
import {BankComponent} from './http/bank.component'  //Web api

import { AppComponent } from './app.component';
import { MusicComponent } from './http/ITunes/music.component';
import { SharedModule } from './shared/shared.module';
import { NewLoginComponent } from './login/newlogin.component';

import { TemperaturePipe } from './pipes/temparature.pipe'
import {TestPipeComponent} from './pipes/testpipe.component'

import { TestDirectiveComponent } from './directives/testdirective.component';
import { HiddenDirective } from './directives/hidden.directive';
import { HoverFocusDirective } from './directives/hoverfocus.directive'
import {RxAppComponent} from './http/rxappcomponent'
import { ModelFormComponent } from './formvalidation/formvalidate.component';
import { AgGridComponent } from './http/aggrid.component';

@NgModule({
  declarations: [
    AppComponent,NewLoginComponent,WeatherComponent,
    HttpComponent,MusicComponent, BankComponent,
    TemperaturePipe,TestPipeComponent,
    TestDirectiveComponent,HiddenDirective,HoverFocusDirective,
    RxAppComponent   ,
    ModelFormComponent,
    AgGridComponent

    ],
  imports: [
    BrowserModule, 
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule ,
   
    JsonpModule,SharedModule,
    AgGridModule.withComponents([])
  ],
  
  providers: [],  
  bootstrap: [AppComponent]
})
export class AppModule {
}
 
