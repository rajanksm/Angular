const express = require('express')
const app = express()
//npm install expres
// npm install body-parser --save
//npm install cors --save

const cors = require('cors')

var corsOptions = {
  origin: 'http://localhost:4200',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}
app.use(cors(corsOptions))

//Middleware
const bodyParser = require('body-parser')
app.use(bodyParser.json())


app.listen(8000, () => {
    console.log('Server started and runninng on 8000!')
  })

  app.route('/api/customers').get((req, res) => {
    res.send({
      customers: [{ name: 'Murthy' }, { name: 'Raju' }],
    })
  })

  app.route('/api/customers/:name').get((req, res) => {
    const requestedCustomerName = req.params['name']
    res.send({ name: requestedCustomerName })
  })

  app.route('/api/customers').post((req, res) => {
    res.send(201, req.body)
  })

  app.route('/api/customers/:name').put((req, res) => {
    res.send(200, req.body)
  })

  app.route('/api/cutomers/:name').delete((req, res) => {
    res.sendStatus(204)
  })
