// let supportsCustomElements = ('customElements' in window);

// if (supportsCustomElements) {
//     import('@webcomponents/webcomponentsjs/custom-elements-es5-adapter');
// }
// else {
//     import('@webcomponents/webcomponentsjs/webcomponents-sd-ce');    
// }
