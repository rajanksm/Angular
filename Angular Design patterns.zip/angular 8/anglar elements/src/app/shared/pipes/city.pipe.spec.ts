/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CityPipe } from './city.pipe';

describe('Pipe: Citye', () => {
  it('create an instance', () => {
    let pipe = new CityPipe();
    expect(pipe).toBeTruthy();
  });
});
