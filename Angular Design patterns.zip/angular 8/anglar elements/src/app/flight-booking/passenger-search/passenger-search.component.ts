import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger-search',
  templateUrl: './passenger-search.component.html',
  styleUrls: ['./passenger-search.component.css']
})
export class PassengerSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
